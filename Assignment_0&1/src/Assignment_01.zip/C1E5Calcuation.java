public class C1E5Calcuation {
    public static void main(String []args){
        double i = 9.5*4.5-2.5*3;
        double j = 45.5-3.5;
        System.out.println(i/j);
    }
}
