public class C1E1Welcome {
    /*
        10th Edition
        CS501
        Yuqi Wang
     */
    public static void main(String []args){
        System.out.println("Welcome to Java");
        System.out.println("Welcome to Computer Science");
        System.out.println("Programming is fun");
    }
}
